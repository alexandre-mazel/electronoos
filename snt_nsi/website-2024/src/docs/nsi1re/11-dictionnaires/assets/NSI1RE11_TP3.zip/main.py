import json

with open("cinemas.json") as fichier:
    donnees = json.load(fichier)

    # Intégrer le code des réponses aux questions à partir d'ici