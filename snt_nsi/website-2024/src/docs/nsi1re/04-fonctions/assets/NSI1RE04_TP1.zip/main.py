import turtle
import paysage

# Configuration de turtle.
turtle.speed(0)

# Tracé du paysage.
paysage.dessiner_paysage()

# Boucle des événements.
turtle.mainloop()