from tkinter import *


def quitter_application():
    """Fonction utilisée comme commande à appeler au clic sur le bouton"""
    global fenetre
    fenetre.destroy()


def changer_texte():
    """Modifie le texte du composant label"""
    ...


# Initialisation de l'application
fenetre = Tk()
fenetre.title("Mon application")

# Ajout d'un texte
label = Label(fenetre, text="Bonjour !")
label.pack(padx=10, pady=10)

# Ajout d'un bouton
bouton = Button(fenetre, text="Quitter", command=quitter_application)
bouton.pack(padx=10, pady=10)

# Gestionnaire d'événements
fenetre.mainloop()
