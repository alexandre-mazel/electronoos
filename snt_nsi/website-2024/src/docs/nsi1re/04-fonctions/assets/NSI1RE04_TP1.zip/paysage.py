import turtle
import aide


def mur(x, y, largeur, hauteur):
    """
    Dessine le mur d'une maison.

    x       -- position x du coin inférieur gauche du mur
    y       -- position y du coin inférieur gauche du mur
    largeur -- largeur du mur
    hauteur -- hauteur du mur
    """
    turtle.penup()
    turtle.goto(x, y)
    turtle.pendown()

    # Implémenter le tracé ici


def toit(x, y, base, hauteur):
    """
    Dessine le toit d'une maison.

    x       -- position x du coin inférieur gauche du toit
    y       -- position y du coin inférieur gauche du toit
    base    -- largeur de la base du toit
    hauteur -- hauteur du toit
    """
    turtle.penup()
    turtle.goto(x, y)
    turtle.pendown()

    # Implémenter le tracé ici


def maison(x, y):
    """
    Dessine une maison de 200px de largeur. Le mur fait 100px de hauteur et le toit, 50px de hauteur.

    x -- position x du coin inférieur gauche de la maison
    y -- position y du coin inférieur gauche de la maison
    """
    


def dessiner_paysage():
    """Dessine un paysage de 3 maisons sous Turtle."""
    


# Tests
if __name__ == "__main__":
    aide.grille()
    mur(-300, 0, 200, 100)
    toit(-300, 150, 200, 50)
    maison(0, 0)
    turtle.mainloop()
