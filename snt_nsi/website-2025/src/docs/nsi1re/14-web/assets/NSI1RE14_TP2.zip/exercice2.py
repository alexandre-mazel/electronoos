# Importe les classes du module tkinter
from tkinter import *
# Crée la fenêtre principale de l'application
fenetre = Tk()
# Crée la fenêtre principale de l'application
fenetre.title("Ma première application")
#
label = Label(fenetre, text="Hello, World!", fg="red")
#
label.pack(padx=10, pady=10)
#
bouton = Button(fenetre, text="Quitter", command=fenetre.destroy)
#
bouton.pack(side=RIGHT)
# Lance le gestionnaire d'événements
fenetre.mainloop()