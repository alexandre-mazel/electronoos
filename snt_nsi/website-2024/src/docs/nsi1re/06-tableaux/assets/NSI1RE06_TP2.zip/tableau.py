def tableau_vers_chaine(tableau):
    """
    Renvoie le contenu d'un tableau d'entiers sous forme d'une chaîne de caractères.

    Paramètres :
    tableau -- Tableau d'entiers

    Tests :
    >>> tableau_vers_chaine([1, 2, 3])
    '1 2 3'
    """


def afficher_tableau_2d(tableau):
    """
    Affiche le contenu d'un tableau à deux dimensions d'entiers.

    Paramètres :
    tableau -- Tableau à deux dimensions d'entiers

    Tests :
    >>> afficher_tableau_2d([[1, 2, 3],[4, 5, 6]])
    1 2 3
    4 5 6
    """


def generer_tableau_2d(largeur, hauteur, valeur):
    """
    Renvoie un tableau à deux dimensions de taille "largeur X hauteur" dont les éléments sont initialisés à valeur.

    Paramètres :
    largeur -- Entier correspondant à la largeur du tableau (nombre de colonnes)
    hauteur -- Entier correspondant à la hauteur du tableau (nombre de lignes)
    valeur  -- Valeur initiale de tous les éléments

    Tests :
    >>> t = generer_tableau_2d(4, 3, 1)
    >>> t[1][1] = 0
    >>> afficher_tableau_2d(t)
    1 1 1 1
    1 0 1 1
    1 1 1 1
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()
