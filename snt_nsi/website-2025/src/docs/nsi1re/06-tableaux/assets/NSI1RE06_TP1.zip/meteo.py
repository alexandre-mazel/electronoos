# [NSI1RE06] TP1 - Problème météo
# Heure début : 00h00
# Heure fin   : 00h00


# Remplacez ce commentaire par l'implémentation la fonction rapport


if __name__ == '__main__':
    # Températures mensuelles moyennes de l'année 2021
    temperatures_2021 = []

    # Affichage du rapport
