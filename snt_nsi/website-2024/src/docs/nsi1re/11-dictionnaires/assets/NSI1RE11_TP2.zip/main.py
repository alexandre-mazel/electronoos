import chaines


def ajouter_dictionnaire(reference, ajout):
    """
    Ajoute les valeurs du dictionnaire << ajout >> au dictionnaire de référence

    Paramètres :
    reference - dictionnaire auquel ajouter les données
    ajout - dictionnaire d'où proviennent les données à ajouter

    Tests :
    >>> dic_r = {"a": 1, "b": 2}
    >>> dic_a = {"a": 4, "b": 3, "c": 5}
    >>> ajouter_dictionnaire(dic_r, dic_a)
    >>> dic_r
    {'a': 5, 'b': 5, 'c': 5}
    """
    pass


def compter_mots_fichier(nom_fichier):
    """
    Renvoie un dictionnaire contenant le nombre d'occurrences de chaque mot d'un fichier texte passé en paramètre

    Paramètres :
    nom_fichier - nom du fichier à charger encodé en UTF-8

    Tests :
    >>> occurrences = compter_mots_fichier("les_miserables.txt")
    >>> occurrences["été"] == 172
    True
    """
    return {}


if __name__ == '__main__':
    import doctest

    if doctest.testmod().failed != 0:
        exit(1)

    mots = compter_mots_fichier("les_miserables.txt")
    print(mots)
