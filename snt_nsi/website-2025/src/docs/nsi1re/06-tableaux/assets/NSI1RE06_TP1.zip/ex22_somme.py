# [NSI1RE06] TP1 - Exercice 2.2 - Écriture de la fonction somme
# Heure début : 00h00
# Heure fin   : 00h00


# Remplacez ce commentaire par l'implémentation de la fonction somme et ne la tester qu'avec doctest




if __name__ == "__main__":
    import doctest
    doctest.testmod()