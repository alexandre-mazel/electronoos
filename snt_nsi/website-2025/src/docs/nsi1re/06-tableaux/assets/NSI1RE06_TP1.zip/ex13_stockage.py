# [NSI1RE06] TP1 - Exercice 1.3 - Stockage en mémoire
# Heure début : 00h00
# Heure fin   : 00h00

v1 = 'A'
v2 = v1
v2 = 'B'

# Valeur de v1 :
# Valeur de v2 :

t1 = ['A', 'B', 'C']
t2 = t1
t2[0] = 'D'

# Valeur de t1 :
# Valeur de t2 :