import images


def afficher_dimensions(image):
    """
    Affiche les dimensions de l'image passée en paramètre sous la forme "largeur x hauteur"

    Paramètres :
    image - Tableau à deux dimensions représentant les pixels d'une image

    Tests :
    >>> afficher_dimensions([[0, 0, 0], [0, 0, 0]])
    3 x 2
    >>> afficher_dimensions([[0, 0], [0, 0], [0, 0]])
    2 x 3
    """


def dessiner_bordure(image):
    """
    Ajoute une bordure à l'image passée en paramètre

    Paramètres :
    image - Tableau à deux dimensions représentant les pixels d'une image

    Tests :
    >>> pixels = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
    >>> dessiner_bordure(pixels)
    >>> pixels
    [[1, 1, 1], [1, 0, 1], [1, 1, 1]]
    >>> pixels = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]]
    >>> dessiner_bordure(pixels)
    >>> pixels
    [[1, 1, 1, 1], [1, 0, 0, 1], [1, 0, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]]
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()
