from tkinter import *


def afficher():
    """
    ...
    """
    global affichage, saisie
    affichage.set("Bonjour " + saisie.get() + " !")


fenetre = Tk()
fenetre.title("Salutations")

# Étiquette permettant d'afficher les instructions
texte = Label(fenetre, text='Comment vous appelez-vous ?', height=3)
texte.pack()

# ...
affichage = StringVar()
# ...
label = Label(fenetre, textvariable=affichage, width=30, fg='yellow', bg='black')
label.pack()

# ...
saisie = StringVar()
# ...
entree = Entry(fenetre, textvariable=saisie, width=30)
entree.pack()

# Bouton "Afficher"
bouton_afficher = Button(fenetre, text='Afficher', command=afficher)
bouton_afficher.pack()

# Gestionnaire d'événements
fenetre.mainloop()
