# [NSI1RE06] TP1 - Exercice 1.2 - Génération d'un tableau
# Heure début : 00h00
# Heure fin   : 00h00

# Première expression
print([0] * 4)

# Seconde expression
print([0, 1] * 4)

# Conclusion :
#
#